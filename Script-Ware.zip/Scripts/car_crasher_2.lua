-- // Configuration: \\ --
 
shared.settings = {
['DarkMode'] = true; -- Dark mode on the script itself.
['AntiAfk'] = true; -- Enable anti-afk
['CloseBind'] = Enum.KeyCode.Semicolon; -- Set this to your preferred key to close the menu.
}
 
-- // Loader: \\ --
 
loadstring(game:HttpGet('https://pastebin.com/raw/T7ERd3e8'))()