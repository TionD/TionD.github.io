local A_1 = "Legendary"
local A_2 = 0
local Event = game:GetService("ReplicatedStorage").Events.OpenBox
Event:InvokeServer(A_1, A_2)