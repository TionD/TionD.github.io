local plr = game.Players.LocalPlayer
local cam = workspace.CurrentCamera

while wait() do
   for i = 1, 100 do
       if plr and plr.Character and plr.Character:FindFirstChild("FakeHead") then
           game:GetService("ReplicatedStorage").Events.ReplicateProjectile:FireServer({
               [1] = "Baseball",
               [2] = 277.6,
               [3] = Vector3.new(),
               [4] = plr.Character.FakeHead.CFrame,
               [5] = 100,
               [6] = 0,
               [7] = 0,
               [8] = 0,
               [9] = "Snowball",
               [10] = plr.Character.FakeHead.CFrame.p,
               [11] = false,
               [13] = {
                   workspace.Map.Clips,
                   workspace.Debris,
                   plr.Character,
                   cam
               },
               [15] = false,
               [16] = 1
           })
       end
   end
end