_G.on = true
_G.TimeThatNoMatterWhatHappensItWillServerHop = 65
-- this goes in your auto execute duh
loadstring(game:HttpGet("https://raw.githubusercontent.com/Jakekill871/public-scripts/master/FpsAutofarms"))();