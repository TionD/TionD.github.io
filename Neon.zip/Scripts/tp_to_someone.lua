-- BY Tion_D
-- TP TO ANY PLAYER IN YOUR GAME YOU YOUST NEED THE NAME
-- IF YOU WANT TO GET THE NAME EASILY PRESS F9 + CTRL I WROTE THEM THERE ;)
-- SOME GAMES WILL KICK YOU OR BAN YOU FOR TELEPROTING
-- USE AT YOUR ON RISK IF YOU GET BANNED DONT BLAME ME
-- RE LUNCH WHEN YOU DIE!

local player = game.Players.LocalPlayer.Character
local UI = Instance.new("ScreenGui")
local main_frame = Instance.new("Frame")
local title = Instance.new("TextLabel")
local injector = Instance.new("TextBox")
local tpB = Instance.new("TextButton")

local titleText = "Script by Tion_D. Write the name of the player you want to TP to IN GAME. Remeber there are some games that kick you for teleproting. Use at your own RISK."
local TPTEXT = "Teleport"

UI.Parent = game.CoreGui

main_frame.Parent = UI
main_frame.Size = UDim2.new(0, 223,0, 202)
main_frame.Position = UDim2.new(0.04, 0,0.451, 0)
main_frame.BorderSizePixel = 0
main_frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)

title.Parent = main_frame
title.Size = UDim2.new(0, 223,0, 113)
title.Position = UDim2.new(-0.004, 0,-0.004, 0)
title.Text = titleText
title.TextScaled = true
title.BackgroundTransparency = 1
title.BorderColor3 = Color3.fromRGB(255, 255, 255)
title.Font = Enum.Font.Code

injector.Parent = main_frame
injector.Size = UDim2.new(0, 153,0, 42)
injector.Position = UDim2.new(0.061, 0,0.609, 0)
injector.Text = ""
injector.TextScaled = true
injector.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
injector.BorderSizePixel = 4
injector.TextColor3 = Color3.fromRGB(0, 0, 0)

tpB.Parent = main_frame
tpB.Size = UDim2.new(0, 34,0, 32)
tpB.Position = UDim2.new(0.803, 0,0.634, 0)
tpB.Text = TPTEXT
tpB.TextScaled = true
tpB.BackgroundColor3 = Color3.fromRGB(85, 0, 0)
tpB.BorderSizePixel = 0
tpB.TextColor3 = Color3.fromRGB(255, 255, 255)

for _, playerss in pairs(game.Players:GetChildren()) do
	print("("..playerss.Name..  ") <-- Tion_D WROTE THIS")
end


tpB.Activated:Connect(function()
	for _, players in pairs(game.Players:GetChildren()) do
		if injector.Text == players.Name then
			local playerChar = players.Character
			local playerHMRP = playerChar.HumanoidRootPart
			
			player.HumanoidRootPart.CFrame = playerHMRP.CFrame
	
		end
		if injector.Text == "LeoDuan_YT" then
			print("SORRY YOU WONT TP TO THE MNB OF THE SCRIPT LOLOLOL") -- made this for fun 
		end
	end
end)