loadstring(game:HttpGet('https://system-exodus.com/scripts/misc-releases/VehicleSimulator.lua', true))()
